import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../models/sos_request_model.dart';
import '../../models/user_model.dart';
import '../../services/firestore_service.dart';
import '../../services/location_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_bottom_nav.dart';

// ── Same key already used across the app ──────────────────────────────────────
const String _apiKey = 'AIzaSyCOooBNKqe-MshDk11ADPQQDK7k90W5Sl4';

/// Re-fetch the Directions route only when the rescuer moves this far (metres).
const double _routeRefreshThresholdMeters = 50.0;

/// Minimum seconds between consecutive Directions API calls.
const int _routeDebounceSeconds = 15;

class RescuerAssignedScreen extends StatefulWidget {
  final String sosId;
  const RescuerAssignedScreen({super.key, required this.sosId});

  @override
  State<RescuerAssignedScreen> createState() => _RescuerAssignedScreenState();
}

class _RescuerAssignedScreenState extends State<RescuerAssignedScreen>
    with SingleTickerProviderStateMixin {
  final FirestoreService _firestoreService = FirestoreService.instance;
  final LocationService _locationService = LocationService.instance;

  StreamSubscription? _sosSubscription;
  StreamSubscription? _rescuerLocationSubscription;

  SosRequestModel? _sosRequest;
  UserModel? _rescuerUser;
  Map<String, dynamic>? _rescuerData;

  LatLng? _victimLatLng;
  LatLng? _rescuerLatLng;

  // ── Route / ETA state ──────────────────────────────────────────────────────
  double? _etaMinutes;
  double? _distanceKm;
  bool _routeLoaded = false;
  bool _fetchingDirections = false;
  LatLng? _lastDirectionsFetchLatLng;
  DateTime? _lastDirectionsFetchTime;

  GoogleMapController? _mapController;
  final Set<Marker> _markers = {};
  final Set<Polyline> _polylines = {};

  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  bool _loadingRescuer = false;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(
      begin: 0.7,
      end: 1.0,
    ).animate(_pulseController);
    _listenToSos();
  }

  // ── SOS stream ──────────────────────────────────────────────────────────────
  void _listenToSos() {
    _sosSubscription = _firestoreService.sosRequestStream(widget.sosId).listen((
      sos,
    ) {
      if (!mounted) return;
      setState(() {
        _sosRequest = sos;
        if (sos != null) {
          _victimLatLng = LatLng(sos.latitude, sos.longitude);
        }
      });
      if (sos == null) return;
      _updateVictimMarker();
      if (sos.assignedRescuerId != null && !_loadingRescuer) {
        _loadRescuerAndListen(sos.assignedRescuerId!);
      }
    });
  }

  // ── Load rescuer profile + start live-location stream ──────────────────────
  Future<void> _loadRescuerAndListen(String rescuerId) async {
    _loadingRescuer = true;
    try {
      final user = await _firestoreService.getUserById(rescuerId);
      final rescuerDoc = await _firestoreService.getRescuerById(rescuerId);
      if (!mounted) return;
      setState(() {
        _rescuerUser = user;
        _rescuerData = rescuerDoc;
      });
    } catch (e) {
      debugPrint('Error loading rescuer: $e');
    }

    _rescuerLocationSubscription?.cancel();
    _rescuerLocationSubscription = _firestoreService
        .rescuerStream(rescuerId)
        .listen((data) {
          if (!mounted || data == null) return;
          final lat = data['latitude'] as double?;
          final lng = data['longitude'] as double?;
          if (lat == null || lng == null) return;

          final newLatLng = LatLng(lat, lng);
          setState(() {
            _rescuerLatLng = newLatLng;
            _updateRescuerMarker();
            _animateToFitRoute();
          });

          // Show straight-line fallback ETA while first API call is in flight
          _recalculateEtaFallback(newLatLng);

          // Throttled real-route fetch
          _maybeRefreshRoute(newLatLng);
        });
  }

  // ── Route throttle ─────────────────────────────────────────────────────────
  void _maybeRefreshRoute(LatLng rescuerPos) {
    if (_fetchingDirections || _victimLatLng == null) return;

    final bool noRoute = !_routeLoaded;
    final bool movedEnough =
        _lastDirectionsFetchLatLng == null ||
        _haversineMeters(_lastDirectionsFetchLatLng!, rescuerPos) >=
            _routeRefreshThresholdMeters;
    final bool cooledDown =
        _lastDirectionsFetchTime == null ||
        DateTime.now().difference(_lastDirectionsFetchTime!).inSeconds >=
            _routeDebounceSeconds;

    if (noRoute || (movedEnough && cooledDown)) {
      _fetchDirections(rescuerPos);
    }
  }

  // ── Google Directions API ───────────────────────────────────────────────────
  Future<void> _fetchDirections(LatLng rescuerPos) async {
    _fetchingDirections = true;
    _lastDirectionsFetchLatLng = rescuerPos;
    _lastDirectionsFetchTime = DateTime.now();

    try {
      final uri = Uri.parse(
        'https://maps.googleapis.com/maps/api/directions/json'
        '?origin=${rescuerPos.latitude},${rescuerPos.longitude}'
        '&destination=${_victimLatLng!.latitude},${_victimLatLng!.longitude}'
        '&mode=driving'
        '&alternatives=false'
        '&traffic_model=best_guess'
        '&departure_time=now'
        '&key=$_apiKey',
      );

      final response = await http.get(uri).timeout(const Duration(seconds: 10));
      if (response.statusCode != 200) return;

      final json = jsonDecode(response.body) as Map<String, dynamic>;
      if (json['status'] != 'OK') {
        debugPrint('Directions API (citizen view): ${json['status']}');
        return;
      }

      final routes = json['routes'] as List?;
      if (routes == null || routes.isEmpty) return;

      final route = routes[0] as Map<String, dynamic>;
      final leg = (route['legs'] as List)[0] as Map<String, dynamic>;

      // Prefer traffic-aware duration
      final durField = leg['duration_in_traffic'] ?? leg['duration'];
      final etaSecs = (durField?['value'] as int?) ?? 0;
      final distMeters = (leg['distance']?['value'] as int?) ?? 0;

      final encoded = route['overview_polyline']['points'] as String;
      final List<LatLng> points = _decodePolyline(encoded);

      if (!mounted) return;
      setState(() {
        _etaMinutes = etaSecs / 60.0;
        _distanceKm = distMeters / 1000.0;
        _routeLoaded = true;

        _polylines
          ..clear()
          ..add(
            Polyline(
              polylineId: const PolylineId('rescue_route'),
              points: points,
              color: AppTheme.primaryBlue,
              width: 5,
              startCap: Cap.roundCap,
              endCap: Cap.roundCap,
              jointType: JointType.round,
              geodesic: true,
            ),
          );
      });

      // Fit map to full route
      if (_mapController != null && points.isNotEmpty) {
        _mapController!.animateCamera(
          CameraUpdate.newLatLngBounds(
            _latLngBoundsFrom([rescuerPos, _victimLatLng!, ...points]),
            60,
          ),
        );
      }
    } catch (e) {
      debugPrint('Directions fetch error (citizen): $e');
    } finally {
      _fetchingDirections = false;
    }
  }

  // ── Straight-line ETA fallback (shown before first API result) ─────────────
  void _recalculateEtaFallback(LatLng from) {
    if (_routeLoaded || _victimLatLng == null) return;
    final distKm = _locationService.calculateDistance(
      from.latitude,
      from.longitude,
      _victimLatLng!.latitude,
      _victimLatLng!.longitude,
    );
    if (!mounted) return;
    setState(() {
      _etaMinutes = (distKm / 40) * 60;
      _distanceKm = distKm;
    });
  }

  // ── Polyline decoder (Google Encoded Polyline Algorithm) ───────────────────
  List<LatLng> _decodePolyline(String encoded) {
    final List<LatLng> poly = [];
    int index = 0;
    final int len = encoded.length;
    int lat = 0, lng = 0;
    while (index < len) {
      int b, shift = 0, result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      lat += ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      shift = 0;
      result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      lng += ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      poly.add(LatLng(lat / 1e5, lng / 1e5));
    }
    return poly;
  }

  // ── Haversine (for move-threshold check) ───────────────────────────────────
  double _haversineMeters(LatLng a, LatLng b) {
    const double r = 6371000;
    final double dLat = _rad(b.latitude - a.latitude);
    final double dLng = _rad(b.longitude - a.longitude);
    final double h =
        pow(sin(dLat / 2), 2) +
        cos(_rad(a.latitude)) * cos(_rad(b.latitude)) * pow(sin(dLng / 2), 2);
    return 2 * r * asin(sqrt(h));
  }

  double _rad(double deg) => deg * pi / 180;

  // ── Camera helpers ─────────────────────────────────────────────────────────
  LatLngBounds _latLngBoundsFrom(List<LatLng> points) {
    double minLat = points.first.latitude;
    double maxLat = points.first.latitude;
    double minLng = points.first.longitude;
    double maxLng = points.first.longitude;
    for (final p in points) {
      if (p.latitude < minLat) minLat = p.latitude;
      if (p.latitude > maxLat) maxLat = p.latitude;
      if (p.longitude < minLng) minLng = p.longitude;
      if (p.longitude > maxLng) maxLng = p.longitude;
    }
    return LatLngBounds(
      southwest: LatLng(minLat, minLng),
      northeast: LatLng(maxLat, maxLng),
    );
  }

  void _animateToFitRoute() {
    if (_mapController == null ||
        _victimLatLng == null ||
        _rescuerLatLng == null)
      return;
    _mapController!.animateCamera(
      CameraUpdate.newLatLngBounds(
        LatLngBounds(
          southwest: LatLng(
            min(_rescuerLatLng!.latitude, _victimLatLng!.latitude),
            min(_rescuerLatLng!.longitude, _victimLatLng!.longitude),
          ),
          northeast: LatLng(
            max(_rescuerLatLng!.latitude, _victimLatLng!.latitude),
            max(_rescuerLatLng!.longitude, _victimLatLng!.longitude),
          ),
        ),
        60,
      ),
    );
  }

  // ── Markers ────────────────────────────────────────────────────────────────
  void _updateVictimMarker() {
    if (_victimLatLng == null) return;
    _markers.removeWhere((m) => m.markerId.value == 'victim');
    _markers.add(
      Marker(
        markerId: const MarkerId('victim'),
        position: _victimLatLng!,
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
        infoWindow: const InfoWindow(
          title: '📍 Your Location',
          snippet: 'Rescuer is on the way',
        ),
        zIndex: 1,
      ),
    );
  }

  void _updateRescuerMarker() {
    if (_rescuerLatLng == null) return;
    _markers.removeWhere((m) => m.markerId.value == 'rescuer');
    _markers.add(
      Marker(
        markerId: const MarkerId('rescuer'),
        position: _rescuerLatLng!,
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
        infoWindow: const InfoWindow(
          title: '🚑 Rescuer',
          snippet: 'Heading to you',
        ),
        zIndex: 2,
      ),
    );
  }

  // ── Actions ────────────────────────────────────────────────────────────────
  Future<void> _callRescuer() async {
    final phone = _rescuerUser?.phone ?? _rescuerData?['phone'];
    if (phone == null) return;
    final uri = Uri(scheme: 'tel', path: phone);
    if (await canLaunchUrl(uri)) await launchUrl(uri);
  }

  void _shareLocation() {
    if (_victimLatLng == null) return;
    Share.share(
      'My emergency location: ${_victimLatLng!.latitude}, ${_victimLatLng!.longitude}\n'
      'https://www.google.com/maps/search/?api=1&query=${_victimLatLng!.latitude},${_victimLatLng!.longitude}',
    );
  }

  @override
  void dispose() {
    _sosSubscription?.cancel();
    _rescuerLocationSubscription?.cancel();
    _pulseController.dispose();
    super.dispose();
  }

  // ── Build ──────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final assigned = _sosRequest?.assignedRescuerId != null;
    // Rescuer sets SOS status to 'resolved' on arrive — mission gets 'arrived'
    final arrived =
        _sosRequest?.status == 'resolved' || _sosRequest?.status == 'arrived';

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        backgroundColor: AppTheme.primaryBlue,
        foregroundColor: Colors.white,
        title: const Text(
          'Rescuer Status',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        elevation: 0,
      ),
      body: Column(
        children: [
          // ── "Rescuer can see your location" banner ─────────────────────────
          Container(
            width: double.infinity,
            color: AppTheme.successGreen,
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
            child: const Row(
              children: [
                Icon(Icons.location_on, color: Colors.white, size: 18),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Rescuer can see your live location',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 13,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // ── ETA banner (shown once we have real route data) ────────────────
          if (assigned && _etaMinutes != null) _buildEtaBanner(arrived),

          // ── Map ────────────────────────────────────────────────────────────
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.38,
            child: assigned && _victimLatLng != null
                ? GoogleMap(
                    initialCameraPosition: CameraPosition(
                      target: _victimLatLng!,
                      zoom: 14,
                    ),
                    markers: _markers,
                    polylines: _polylines,
                    onMapCreated: (c) {
                      _mapController = c;
                      if (_rescuerLatLng != null) _animateToFitRoute();
                    },
                    myLocationButtonEnabled: false,
                    trafficEnabled: true,
                    zoomControlsEnabled: true,
                  )
                : _buildWaitingMap(),
          ),

          // ── Bottom info panel ──────────────────────────────────────────────
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: assigned
                  ? _buildAssignedContent(arrived)
                  : _buildWaitingContent(),
            ),
          ),
        ],
      ),
      bottomNavigationBar: AppBottomNav(currentIndex: 0),
    );
  }

  // ── ETA banner widget ──────────────────────────────────────────────────────
  Widget _buildEtaBanner(bool arrived) {
    if (arrived) {
      return Container(
        width: double.infinity,
        color: AppTheme.successGreen,
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.check_circle, color: Colors.white),
            SizedBox(width: 8),
            Text(
              'Rescuer has arrived!',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 15,
              ),
            ),
          ],
        ),
      );
    }

    final eta = _etaMinutes!;
    final dist = _distanceKm;
    final isRealRoute = _routeLoaded;

    return Container(
      width: double.infinity,
      color: AppTheme.primaryBlue,
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.timer_outlined, color: Colors.white, size: 20),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'ETA: ${eta.toStringAsFixed(0)} min'
                '${dist != null ? '  •  ${dist.toStringAsFixed(1)} km' : ''}',
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                ),
              ),
              Text(
                isRealRoute ? 'Via fastest road route' : 'Estimating…',
                style: const TextStyle(color: Colors.white70, fontSize: 11),
              ),
            ],
          ),
          if (!isRealRoute) ...[
            const SizedBox(width: 10),
            const SizedBox(
              width: 14,
              height: 14,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: Colors.white,
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ── Waiting state ──────────────────────────────────────────────────────────
  Widget _buildWaitingMap() {
    return Container(
      color: Colors.grey[200],
      child: const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.map_outlined, size: 48, color: Colors.grey),
            SizedBox(height: 8),
            Text(
              'Waiting for rescuer assignment…',
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWaitingContent() {
    return Column(
      children: [
        const SizedBox(height: 16),
        AnimatedBuilder(
          animation: _pulseAnimation,
          builder: (_, __) => Opacity(
            opacity: _pulseAnimation.value,
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.06),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: const Column(
                children: [
                  CircularProgressIndicator(color: AppTheme.primaryBlue),
                  SizedBox(height: 16),
                  Text(
                    'Waiting for rescuer…',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Your SOS has been received.',
                    style: TextStyle(color: AppTheme.textSecondary),
                  ),
                  SizedBox(height: 4),
                  Text(
                    'A rescuer will be assigned shortly.',
                    style: TextStyle(color: AppTheme.textSecondary),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.successGreen.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppTheme.successGreen.withOpacity(0.3)),
          ),
          child: const Row(
            children: [
              Icon(Icons.check_circle, color: AppTheme.successGreen),
              SizedBox(width: 12),
              Expanded(
                child: Text(
                  'SOS request submitted successfully.',
                  style: TextStyle(
                    color: AppTheme.successGreen,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ── Assigned state ─────────────────────────────────────────────────────────
  Widget _buildAssignedContent(bool arrived) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Status chip
        Center(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            decoration: BoxDecoration(
              color: arrived ? AppTheme.successGreen : AppTheme.primaryBlue,
              borderRadius: BorderRadius.circular(24),
            ),
            child: Text(
              arrived ? '✅  Arrived' : '🚐  En Route',
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 15,
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),

        // Rescuer info card
        if (_rescuerData != null || _rescuerUser != null)
          Card(
            elevation: 2,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Rescuer Info',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  const Divider(height: 20),
                  _infoRow(
                    Icons.groups,
                    _rescuerData?['team_name'] ?? 'Unknown Team',
                  ),
                  _infoRow(
                    Icons.account_balance,
                    _rescuerData?['agency'] ?? 'Unknown Agency',
                  ),
                  _infoRow(Icons.badge, _rescuerData?['badge_number'] ?? 'N/A'),
                  _infoRow(
                    Icons.person,
                    _rescuerData?['lead_officer'] ??
                        _rescuerUser?.displayName ??
                        'Unknown Officer',
                  ),
                ],
              ),
            ),
          ),
        const SizedBox(height: 16),

        // Route info card (shown once real route is loaded)
        if (_routeLoaded && _etaMinutes != null)
          Card(
            elevation: 2,
            color: AppTheme.primaryBlue.withOpacity(0.05),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
              side: BorderSide(color: AppTheme.primaryBlue.withOpacity(0.2)),
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                children: [
                  const Icon(
                    Icons.route,
                    color: AppTheme.primaryBlue,
                    size: 28,
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${_etaMinutes!.toStringAsFixed(0)} min  •  ${_distanceKm?.toStringAsFixed(1) ?? '--'} km',
                        style: TextStyle(
                          color: AppTheme.primaryBlue,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      const Text(
                        'Fastest road route · real-time traffic',
                        style: TextStyle(
                          color: AppTheme.textSecondary,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        const SizedBox(height: 16),

        // Call button
        ElevatedButton.icon(
          onPressed: _callRescuer,
          icon: const Icon(Icons.phone),
          label: const Text('Call Rescuer'),
          style: ElevatedButton.styleFrom(
            backgroundColor: AppTheme.successGreen,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),
        const SizedBox(height: 10),

        // Share location button
        OutlinedButton.icon(
          onPressed: _shareLocation,
          icon: const Icon(Icons.share),
          label: const Text('Share Location'),
          style: OutlinedButton.styleFrom(
            foregroundColor: AppTheme.primaryBlue,
            side: const BorderSide(color: AppTheme.primaryBlue),
            padding: const EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),
      ],
    );
  }

  Widget _infoRow(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Icon(icon, size: 18, color: AppTheme.primaryBlue),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 14))),
        ],
      ),
    );
  }
}
