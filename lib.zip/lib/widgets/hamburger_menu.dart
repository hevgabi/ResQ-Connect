import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/auth_provider.dart' as app_auth;
import '../screens/entry/login_screen.dart';
import '../screens/settings/settings_screen.dart';
import '../theme/app_theme.dart';

// =============================================================================
// PUBLIC HELPER
// =============================================================================

void showHamburgerMenu(
  BuildContext context, {
  HamburgerRole role = HamburgerRole.citizen,
}) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (_) => HamburgerMenuSheet(role: role),
  );
}

enum HamburgerRole { citizen, rescuer, moderator }

// =============================================================================
// MAIN SHEET
// =============================================================================

class HamburgerMenuSheet extends StatelessWidget {
  final HamburgerRole role;
  const HamburgerMenuSheet({super.key, required this.role});

  static const _blue = Color(0xFF0D47A1);
  static const _green = Color(0xFF1FAA59);
  static const _purple = Color(0xFF6A1B9A);
  static const _grey = Color(0xFF546E7A);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            // Drag handle
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Role-specific content
            if (role == HamburgerRole.citizen) ...[
              _sectionLabel('Support'),
              _menuTile(
                context,
                icon: Icons.help_outline,
                iconColor: _blue,
                label: 'Help & Support',
                badge: 'Coming Soon',
                onTap: () {
                  Navigator.pop(context);
                  _snackComingSoon(context);
                },
              ),
              const SizedBox(height: 8),
            ],

            if (role == HamburgerRole.rescuer) ...[
              _sectionLabel('Duty Status'),
              const _RescuerDutyTile(),
              const SizedBox(height: 12),
              _sectionLabel('Team Info'),
              const _RescuerTeamInfoCard(),
              const SizedBox(height: 12),
              _sectionLabel('Support'),
              _menuTile(
                context,
                icon: Icons.help_outline,
                iconColor: _green,
                label: 'Help & Support',
                badge: 'Coming Soon',
                onTap: () {
                  Navigator.pop(context);
                  _snackComingSoon(context);
                },
              ),
              const SizedBox(height: 8),
            ],

            if (role == HamburgerRole.moderator) ...[
              _sectionLabel('Support'),
              _menuTile(
                context,
                icon: Icons.help_outline,
                iconColor: _purple,
                label: 'Help & Support',
                badge: 'Coming Soon',
                onTap: () {
                  Navigator.pop(context);
                  _snackComingSoon(context);
                },
              ),
              const SizedBox(height: 8),
            ],

            const Divider(),
            const SizedBox(height: 4),

            // Settings & Privacy
            _menuTile(
              context,
              icon: Icons.settings_outlined,
              iconColor: _grey,
              label: 'Settings & Privacy',
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const SettingsScreen()),
                );
              },
            ),

            // Log Out
            _menuTile(
              context,
              icon: Icons.logout,
              iconColor: AppTheme.dangerRed,
              label: 'Log Out',
              labelColor: AppTheme.dangerRed,
              onTap: () {
                Navigator.pop(context);
                _showLogoutDialog(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  // ── Helpers ────────────────────────────────────────────────────────────────
  Widget _sectionLabel(String text) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Text(
      text,
      style: const TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w700,
        color: Color(0xFF90A4AE),
        letterSpacing: 0.5,
      ),
    ),
  );

  Widget _menuTile(
    BuildContext context, {
    required IconData icon,
    required Color iconColor,
    required String label,
    Color? labelColor,
    String? badge,
    required VoidCallback onTap,
  }) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 4),
      leading: Container(
        padding: const EdgeInsets.all(9),
        decoration: BoxDecoration(
          color: iconColor.withAlpha(20),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: iconColor, size: 20),
      ),
      title: Text(
        label,
        style: TextStyle(
          fontWeight: FontWeight.w600,
          fontSize: 14,
          color: labelColor ?? const Color(0xFF263238),
        ),
      ),
      trailing: badge != null
          ? Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: const Color(0xFF546E7A).withAlpha(20),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                badge,
                style: const TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF546E7A),
                ),
              ),
            )
          : const Icon(Icons.chevron_right, color: Color(0xFF90A4AE), size: 20),
      onTap: onTap,
    );
  }

  void _snackComingSoon(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Help & Support — Coming Soon!'),
        backgroundColor: const Color(0xFF0D47A1),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    final authProvider = context.read<app_auth.AuthProvider>();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text(
          'Log Out',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        content: const Text(
          'Are you sure you want to log out of your account?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.dangerRed,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            onPressed: () async {
              Navigator.pop(ctx);
              await authProvider.logout();
              if (context.mounted) {
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                  (route) => false,
                );
              }
            },
            child: const Text('Log Out'),
          ),
        ],
      ),
    );
  }
}

// =============================================================================
// RESCUER DUTY TOGGLE
// =============================================================================

class _RescuerDutyTile extends StatefulWidget {
  const _RescuerDutyTile();

  @override
  State<_RescuerDutyTile> createState() => _RescuerDutyTileState();
}

class _RescuerDutyTileState extends State<_RescuerDutyTile> {
  bool _isOnDuty = false;
  bool _loading = true;

  static const _green = Color(0xFF1FAA59);
  static const _grey = Color(0xFF546E7A);

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final uid = context.read<app_auth.AuthProvider>().user?.uid;
    if (uid == null) {
      setState(() => _loading = false);
      return;
    }
    try {
      final doc = await FirebaseFirestore.instance
          .collection('rescuers')
          .doc(uid)
          .get();
      if (mounted)
        setState(() {
          _isOnDuty = (doc.data()?['is_on_duty'] as bool?) ?? false;
          _loading = false;
        });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _toggle(bool value) async {
    final uid = context.read<app_auth.AuthProvider>().user?.uid;
    if (uid == null) return;
    setState(() => _isOnDuty = value);
    await FirebaseFirestore.instance.collection('rescuers').doc(uid).update({
      'is_on_duty': value,
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE0E0E0)),
      ),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(9),
          decoration: BoxDecoration(
            color: (_isOnDuty ? _green : _grey).withAlpha(20),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(
            _isOnDuty
                ? Icons.check_circle_outline
                : Icons.radio_button_unchecked,
            color: _isOnDuty ? _green : _grey,
            size: 20,
          ),
        ),
        title: Text(
          _isOnDuty ? 'On Duty' : 'Off Duty',
          style: TextStyle(
            fontWeight: FontWeight.w700,
            fontSize: 14,
            color: _isOnDuty ? _green : _grey,
          ),
        ),
        subtitle: Text(
          _isOnDuty
              ? 'Visible to new SOS requests'
              : 'Not receiving new missions',
          style: const TextStyle(fontSize: 11, color: Color(0xFF90A4AE)),
        ),
        trailing: _loading
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: Color(0xFF1FAA59),
                ),
              )
            : Switch(value: _isOnDuty, onChanged: _toggle, activeColor: _green),
      ),
    );
  }
}

// =============================================================================
// RESCUER TEAM INFO
// =============================================================================

class _RescuerTeamInfoCard extends StatefulWidget {
  const _RescuerTeamInfoCard();

  @override
  State<_RescuerTeamInfoCard> createState() => _RescuerTeamInfoCardState();
}

class _RescuerTeamInfoCardState extends State<_RescuerTeamInfoCard> {
  Map<String, dynamic>? _data;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final uid = context.read<app_auth.AuthProvider>().user?.uid;
    if (uid == null) {
      setState(() => _loading = false);
      return;
    }
    try {
      final doc = await FirebaseFirestore.instance
          .collection('rescuers')
          .doc(uid)
          .get();
      if (mounted)
        setState(() {
          _data = doc.data();
          _loading = false;
        });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(16),
          child: CircularProgressIndicator(
            strokeWidth: 2,
            color: Color(0xFF1FAA59),
          ),
        ),
      );
    }
    if (_data == null) {
      return const Text(
        'Could not load team info.',
        style: TextStyle(color: Color(0xFF90A4AE), fontSize: 13),
      );
    }
    final active = (_data!['active_mission_count'] ?? 0) as int;
    final max = (_data!['team_capacity_max'] ?? 5) as int;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE0E0E0)),
      ),
      child: Column(
        children: [
          _row(
            Icons.badge_outlined,
            'Badge Number',
            _data!['badge_number'] ?? 'N/A',
          ),
          const SizedBox(height: 10),
          _row(
            Icons.business_outlined,
            'Agency',
            _data!['agency_name'] ?? 'N/A',
          ),
          const SizedBox(height: 10),
          _row(
            Icons.group_outlined,
            'Team ID',
            _data!['team_id']?.toString() ?? 'Unassigned',
          ),
          const SizedBox(height: 10),
          _row(
            Icons.assignment_ind_outlined,
            'Capacity',
            '$active / $max missions',
          ),
        ],
      ),
    );
  }

  Widget _row(IconData icon, String label, String value) => Row(
    children: [
      Icon(icon, size: 16, color: const Color(0xFF90A4AE)),
      const SizedBox(width: 10),
      Text(
        '$label: ',
        style: const TextStyle(fontSize: 13, color: Color(0xFF546E7A)),
      ),
      Expanded(
        child: Text(
          value,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w700,
            color: Color(0xFF263238),
          ),
          overflow: TextOverflow.ellipsis,
        ),
      ),
    ],
  );
}
