import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../screens/citizen/citizen_home_screen.dart';
import '../screens/citizen/live_map_screen.dart';
import '../screens/citizen/sos_trigger_screen.dart';
import '../screens/citizen/rescuer_assigned_screen.dart';
import '../screens/citizen/emergency_hotlines_screen.dart';
import '../screens/citizen/citizen_profile_screen.dart';

class AppBottomNav extends StatefulWidget {
  final int currentIndex;
  final ValueChanged<int>? onTap;
  const AppBottomNav({super.key, required this.currentIndex, this.onTap});

  @override
  State<AppBottomNav> createState() => _AppBottomNavState();
}

class _AppBottomNavState extends State<AppBottomNav> {
  bool _navigating = false;

  Future<void> _handleTap(int index) async {
    if (_navigating) return;
    if (index == widget.currentIndex) return;

    if (widget.onTap != null) {
      widget.onTap!(index);
      return;
    }

    // SOS tab — check for an active SOS first
    if (index == 2) {
      setState(() => _navigating = true);
      try {
        final uid = FirebaseAuth.instance.currentUser?.uid;
        if (uid != null) {
          final snap = await FirebaseFirestore.instance
              .collection('sos_requests')
              .where('citizen_id', isEqualTo: uid)
              .where('status', whereIn: ['open', 'assigned'])
              .orderBy('created_at', descending: true)
              .limit(1)
              .get();

          if (!mounted) return;

          if (snap.docs.isNotEmpty) {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(
                builder: (_) =>
                    RescuerAssignedScreen(sosId: snap.docs.first.id),
              ),
                  (route) => false,
            );
            return;
          }
        }

        if (!mounted) return;
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (_) => const SosTriggerScreen()),
              (route) => false,
        );
      } catch (_) {
        // On any error fall back to SOS trigger screen
        if (mounted) {
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (_) => const SosTriggerScreen()),
                (route) => false,
          );
        }
      } finally {
        if (mounted) setState(() => _navigating = false);
      }
      return;
    }

    final screens = <Widget>[
      const CitizenHomeScreen(),
      const LiveMapScreen(),
      const SosTriggerScreen(),
      const EmergencyHotlinesScreen(),
      const CitizenProfileScreen(),
    ];

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => screens[index]),
          (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: widget.currentIndex,
      onTap: _handleTap,
      type: BottomNavigationBarType.fixed,
      backgroundColor: Colors.white,
      selectedItemColor: const Color(0xFF0D47A1),
      unselectedItemColor: const Color(0xFF546E7A),
      selectedLabelStyle: const TextStyle(
        fontWeight: FontWeight.w600,
        fontSize: 11,
      ),
      unselectedLabelStyle: const TextStyle(
        fontWeight: FontWeight.w400,
        fontSize: 11,
      ),
      elevation: 12,
      items: [
        const BottomNavigationBarItem(
          icon: Icon(Icons.home_outlined),
          activeIcon: Icon(Icons.home),
          label: 'Home',
        ),
        const BottomNavigationBarItem(
          icon: Icon(Icons.map_outlined),
          activeIcon: Icon(Icons.map),
          label: 'Map',
        ),
        // SOS — use IgnorePointer=false explicitly so the container never
        // swallows the tap; the BottomNavigationBar's own InkWell handles it.
        const BottomNavigationBarItem(
          icon: _SosIcon(),
          label: 'SOS',
        ),
        const BottomNavigationBarItem(
          icon: Icon(Icons.phone_outlined),
          activeIcon: Icon(Icons.phone),
          label: 'Hotlines',
        ),
        const BottomNavigationBarItem(
          icon: Icon(Icons.person_outline),
          activeIcon: Icon(Icons.person),
          label: 'Profile',
        ),
      ],
    );
  }
}

// Separate const widget so the BottomNavigationBar can render it without
// the Container intercepting pointer events.
class _SosIcon extends StatelessWidget {
  const _SosIcon();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: const BoxDecoration(
        color: Color(0xFFD7263D),
        shape: BoxShape.circle,
      ),
      child: const Icon(Icons.sos, color: Colors.white, size: 22),
    );
  }
}